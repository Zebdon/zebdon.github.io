# 🚀 MetaboFit - Landing Page

Página web profesional para captar usuarios en la lista de espera de MetaboFit.

## 📦 Archivos Incluidos

- `index.html` - Página principal
- `styles.css` - Estilos CSS
- `script.js` - JavaScript interactivo
- `README.md` - Este archivo

## 🌐 Publicar en GitHub Pages (GRATIS)

### Opción 1: Interfaz Web de GitHub (Más Fácil)

1. **Crea una cuenta en GitHub** (si no tienes):
   - Ve a https://github.com/signup
   - Regístrate gratis

2. **Crea un nuevo repositorio**:
   - Click en "New repository" (botón verde)
   - Nombre: `metabofit-landing` o `tuusuario.github.io`
   - Marca como "Public"
   - Click "Create repository"

3. **Sube los archivos**:
   - Click en "uploading an existing file"
   - Arrastra los 3 archivos: `index.html`, `styles.css`, `script.js`
   - Click "Commit changes"

4. **Activa GitHub Pages**:
   - Ve a Settings → Pages (menú lateral)
   - En "Source", selecciona "main" branch
   - Click "Save"
   - ¡Tu sitio estará en: `https://tuusuario.github.io/metabofit-landing`!

### Opción 2: Con Git (Para usuarios avanzados)

```bash
# 1. Inicializa el repositorio
git init
git add .
git commit -m "Initial commit - MetaboFit landing page"

# 2. Conecta con GitHub
git remote add origin https://github.com/tuusuario/metabofit-landing.git
git branch -M main
git push -u origin main

# 3. GitHub Pages se activará automáticamente si el repo se llama tuusuario.github.io
```

## 📧 Configurar Captura de Emails

### Opción A: Formspree (Recomendado - GRATIS)

1. Ve a https://formspree.io/
2. Regístrate gratis (50 emails/mes gratis)
3. Crea un nuevo formulario
4. Copia tu Form ID
5. En `script.js`, línea 27, reemplaza:
   ```javascript
   const response = await fetch('https://formspree.io/f/TU_FORM_ID', {
   ```

### Opción B: Google Forms + Apps Script

1. Crea un Google Form
2. Agrega campos: Nombre, Email, Condición
3. Obtén el ID del formulario
4. Usa este endpoint en `script.js`

### Opción C: Netlify Forms (Sin configuración)

1. Sube a Netlify (siguiente sección)
2. Agrega `netlify` al atributo del form
3. Los emails llegarán a tu dashboard de Netlify

## 🎨 Personalización Fácil

### Cambiar Colores

En `styles.css`, líneas 9-16:
```css
:root {
    --primary: #3B82F6;      /* Azul principal */
    --secondary: #10B981;    /* Verde secundario */
    --accent: #8B5CF6;       /* Morado acento */
}
```

### Cambiar Textos

Edita directamente en `index.html`:
- Línea 11: Título de la página
- Líneas 44-48: Hero title
- Todo el contenido es editable

### Agregar Logo Propio

1. Sube tu logo a GitHub
2. En `index.html`, línea 17-21, reemplaza el SVG con:
   ```html
   <img src="tu-logo.png" alt="MetaboFit" width="32">
   ```

## 📊 Agregar Google Analytics

1. Crea cuenta en Google Analytics
2. Obtén tu ID de medición (G-XXXXXXXXXX)
3. Agrega antes del `</head>` en `index.html`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

## 🌍 Alternativas de Hosting GRATIS

### Netlify (Recomendado para principiantes)
1. Ve a https://netlify.com
2. Arrastra la carpeta del proyecto
3. ¡Listo! Tendrás un dominio tipo `random-name.netlify.app`
4. Puedes conectar dominio propio después

### Vercel
1. Ve a https://vercel.com
2. Importa desde GitHub
3. Deploy automático

### Cloudflare Pages
1. Ve a https://pages.cloudflare.com
2. Conecta GitHub
3. Deploy automático + CDN gratis

## 🔗 Obtener Dominio Propio

### Dominios GRATIS (1 año):
- Freenom: .tk, .ml, .ga, .cf, .gq (gratis)
- GitHub Student Pack: Dominio .me gratis por 1 año

### Dominios Baratos:
- Namecheap: ~$10/año (.com)
- Google Domains: ~$12/año
- Cloudflare: Al costo (~$8/año)

### Conectar dominio a GitHub Pages:
1. En tu proveedor de dominio, agrega estos DNS:
   - A record → 185.199.108.153
   - A record → 185.199.109.153
   - A record → 185.199.110.153
   - A record → 185.199.111.153
2. En GitHub Settings → Pages → Custom domain
3. Escribe tu dominio y guarda

## 📱 Probar en Móvil

### Localhost en tu móvil:
```bash
# En tu computadora:
python3 -m http.server 8000

# Busca tu IP local:
# Mac/Linux: ifconfig | grep inet
# Windows: ipconfig

# En tu móvil, abre el navegador:
http://TU_IP_LOCAL:8000
```

## ✅ Checklist Pre-Lanzamiento

- [ ] Configurar Formspree para emails
- [ ] Agregar Google Analytics
- [ ] Probar formulario de registro
- [ ] Verificar en móvil (responsive)
- [ ] Revisar ortografía
- [ ] Cambiar enlaces de redes sociales (footer)
- [ ] Agregar favicon (ícono de pestaña)
- [ ] Optimizar imágenes (comprimir)
- [ ] Configurar dominio propio (opcional)
- [ ] Crear página de privacidad y términos

## 🚀 Marketing Inicial (Sin presupuesto)

1. **Reddit**:
   - r/diabetes (500K miembros)
   - r/startups
   - r/SideProject
   - NO hagas spam, comparte genuinamente

2. **Product Hunt**:
   - Programa lanzamiento para un jueves
   - Prepara screenshots y video demo

3. **Twitter/X**:
   - Hilo explicando el problema
   - Tag: #diabetes #healthtech #startup

4. **LinkedIn**:
   - Post sobre el proyecto
   - Grupos de salud y tecnología

5. **Facebook Groups**:
   - Grupos de diabetes en español
   - Grupos de emprendimiento

## 📈 Seguimiento de Resultados

Métricas que debes rastrear:
- Visitantes únicos (Google Analytics)
- Tasa de conversión (visitas → registros)
- Fuente de tráfico (¿de dónde vienen?)
- Tiempo en página
- Tasa de rebote

**Objetivo inicial**: 100 registros en primer mes

## 🔧 Solución de Problemas

### "Mi página no se ve bien en móvil"
- Asegúrate de tener viewport meta tag (ya está en el código)
- Prueba con Chrome DevTools (F12 → Toggle device toolbar)

### "El formulario no envía emails"
- Verifica tu Form ID de Formspree
- Revisa la consola del navegador (F12) para errores
- Prueba con tu propio email primero

### "Las imágenes no cargan"
- Las imágenes actuales usan URLs de GenSpark
- Descárgalas y súbelas a tu repositorio
- Cambia las URLs en `index.html`

### "Quiero cambiar el idioma a inglés"
- Traduce los textos en `index.html`
- Cambia `lang="es"` a `lang="en"` en línea 2

## 💡 Próximos Pasos

Una vez tengas 100+ registros:

1. **Email de bienvenida**: Crea secuencia automática
2. **Encuesta**: Pregunta qué features quieren
3. **MVP**: Empieza con prototipo simple
4. **Fundraising**: Con traction, busca inversión
5. **Comunidad**: Crea Discord/Telegram

## 🤝 Soporte

¿Necesitas ayuda?
- Revisa documentación de GitHub Pages
- Ve tutoriales en YouTube: "How to deploy to GitHub Pages"
- Pregunta en Stack Overflow

## 📄 Licencia

Este código es tuyo. Úsalo libremente para tu proyecto.

---

**¡Éxito con tu lanzamiento! 🚀**

Recuerda: La primera versión no tiene que ser perfecta.
Lo importante es LANZAR y obtener feedback real de usuarios.

*"Done is better than perfect"* - Reid Hoffman (Fundador de LinkedIn)